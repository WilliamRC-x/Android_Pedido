package com.android.pedidos.model

import java.math.BigDecimal

class Pedido(
    val titulo: String,
    val descricao: String,
    val valor: BigDecimal
)