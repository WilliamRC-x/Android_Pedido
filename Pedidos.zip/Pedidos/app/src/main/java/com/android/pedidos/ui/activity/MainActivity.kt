package com.android.pedidos.ui.activity

import android.app.Activity
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.pedidos.R
import com.android.pedidos.model.Pedido
import com.android.pedidos.ui.recyclerview.adapter.ListaPedidosAdapter
import java.math.BigDecimal

class MainActivity : AppCompatActivity(R.layout.activity_main) {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //Biding de Layout
//        val titulo = findViewById<TextView>(R.id.titulo)
//        titulo.text = "Lista de Pedidos"
//        val descricao = findViewById<TextView>(R.id.descricao)
//        descricao.text = "Pedido, Situação, Valor"
//        val valor = findViewById<TextView>(R.id.valor)
//        valor.text = "250.00"
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerview)
        recyclerView.adapter = ListaPedidosAdapter(context = this, pedidos = listOf(
            Pedido(
                titulo = "teste",
                descricao = "testdesc",
                valor = BigDecimal("250.00")
            ),
            Pedido(
                titulo = "teste 1",
                descricao = "testdesc 1",
                valor = BigDecimal("260.00")
            ),
            Pedido(
                titulo = "teste 2",
                descricao = "testdesc 2",
                valor = BigDecimal("270.00")
            ),
        ))
//        recyclerView.layoutManager = LinearLayoutManager(this)
    }
}