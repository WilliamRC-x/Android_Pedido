package com.android.pedidos.ui.recyclerview.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.android.pedidos.R
import com.android.pedidos.model.Pedido

class ListaPedidosAdapter(
    private val context: Context,
    private val pedidos: List<Pedido>
) : RecyclerView.Adapter<ListaPedidosAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        fun vicula(pedido: Pedido) {
            val titulo = itemView.findViewById<TextView>(R.id.titulo)
            titulo.text = pedido.titulo
            val descricao = itemView.findViewById<TextView>(R.id.descricao)
            descricao.text = pedido.descricao
            val valor = itemView.findViewById<TextView>(R.id.valor)
            valor.text = pedido.valor.toPlainString()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflater = LayoutInflater.from(context)
        val view = inflater.inflate(R.layout.pedido_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val pedido = pedidos[position]
        holder.vicula(pedido)
    }

    override fun getItemCount(): Int = pedidos.size
}
